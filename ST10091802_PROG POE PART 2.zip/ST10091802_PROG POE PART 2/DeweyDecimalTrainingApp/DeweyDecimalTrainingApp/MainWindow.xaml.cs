﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace DeweyDecimalTrainingApp
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private int score = 0;
        private int level = 1;
        private List<MatchingQuestion> identifyingAreasQuestions;
        private int currentQuestionIndex;
        private int correctAnswers;

        public ObservableCollection<string> BookNumbers { get; set; }
        public string ScoreLabelText { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            BookNumbers = new ObservableCollection<string>();
            DataContext = this;
            UpdateUI();
            identifyingAreasQuestions = InitializeIdentifyingAreasQuestions();
            currentQuestionIndex = 0;
        }

        private void UpdateUI()
        {
            ScoreLabelText = $"Score: {score}";
            TaskListBox.Items.Clear();
            TaskListBox.Items.Add("1. Replacing books");
            TaskListBox.Items.Add("2. Identifying areas");
            TaskListBox.Items.Add("3. Finding call numbers");
            TaskListBox.Items.Add("4. Show Score");
            TaskListBox.Items.Add("5. Quit");
        }

        private void StartTaskButton_Click(object sender, RoutedEventArgs e)
        {
            if (TaskListBox.SelectedIndex == 0)
            {
                ReplaceBooksTask();
            }
            else if (TaskListBox.SelectedIndex == 1)
            {
                StartIdentifyingAreasTask();
            }
            else if (TaskListBox.SelectedIndex == 2)
            {
                FindingCallNumbersTask();
            }
            else if (TaskListBox.SelectedIndex == 4)
            {
                ShowScoreButton_Click(null, null);
            }
            else if (TaskListBox.SelectedIndex == 5)
            {
                Environment.Exit(0);
            }
        }

        private void ReplaceBooksTask()
        {
            int booksToReplace = 5;
            int booksReplaced = 0;

            for (int i = 0; i < booksToReplace; i++)
            {
                if (ReplaceBook())
                {
                    booksReplaced++;
                }
            }

            score += booksReplaced * 10;
            ScoreLabelText = $"Score: {score}";

            if (score >= level * 100)
            {
                level++;
                MessageBox.Show($"Congratulations! You've reached Level {level}.", "Level Up", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            MessageBox.Show($"You have successfully replaced {booksReplaced} out of {booksToReplace} books.", "Task Complete", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private bool ReplaceBook()
        {
            Random random = new Random();
            double successProbability = 0.7;

            double randomValue = random.NextDouble();
            bool isSuccessful = randomValue <= successProbability;

            if (isSuccessful)
            {
                BookNumbers.Add("Replaced Book");
            }
            else
            {
                BookNumbers.Add("Failed Replacement");
            }

            return isSuccessful;
        }

        private void FindingCallNumbersTask()
        {
            int callNumbersToFind = 5;
            int callNumbersFound = 0;

            for (int i = 0; i < callNumbersToFind; i++)
            {
                if (FindCallNumber())
                {
                    callNumbersFound++;
                }
            }

            score += callNumbersFound * 10;
            ScoreLabelText = $"Score: {score}";

            if (score >= level * 100)
            {
                level++;
                MessageBox.Show($"Congratulations! You've reached Level {level}.", "Level Up", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            MessageBox.Show($"You have successfully found {callNumbersFound} out of {callNumbersToFind} call numbers.", "Task Complete", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private bool FindCallNumber()
        {
            Random random = new Random();
            return random.Next(1, 11) <= 6; // 60% success rate
        }

        private void StartIdentifyingAreasTask()
        {
            if (identifyingAreasQuestions.Count == 0)
            {
                MessageBox.Show("No Identifying Areas questions available.", "Task Complete", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            TaskListBox.IsEnabled = false;
            StartTaskButton.IsEnabled = false;

            TaskContainer.Children.Clear();

            MatchingQuestion question = identifyingAreasQuestions[currentQuestionIndex];

            if (currentQuestionIndex % 2 == 0)
            {
                question.GenerateRandomOptionsDescriptionsToCallNumbers();
            }
            else
            {
                question.GenerateRandomOptionsCallNumbersToDescriptions();
            }

            for (int i = 0; i < question.Options.Count; i++)
            {
                var descriptionTextBlock = new TextBlock
                {
                    Text = question.Options[i],
                    VerticalAlignment = VerticalAlignment.Center,
                };

                var comboBox = new ComboBox
                {
                    ItemsSource = question.Options,
                    SelectedIndex = -1,
                    VerticalAlignment = VerticalAlignment.Center,
                    Width = 150,
                };

                TaskContainer.Children.Add(descriptionTextBlock);
                TaskContainer.Children.Add(comboBox);
            }
        }
        private void GenerateNumbersButton_Click(object sender, RoutedEventArgs e)
{
    string message = "Generated Numbers:\n";

            // Generate 10 random 3-digit numbers and add them to the message
            // How to Generate a Random Number and Random String in C#?
           // https://www.c-sharpcorner.com/article/generating-random-number-and-string-in-C-Sharp/
          //Mahesh Chand
          //https://www.c-sharpcorner.com/members/mahesh-chand

            Random random = new Random();
    for (int i = 0; i < 10; i++)
    {
        int randomNumber = random.Next(100, 1000); // Generates random 3-digit numbers
        message += randomNumber + "\n";
    }

    MessageBox.Show(message, "Generated Numbers", MessageBoxButton.OK, MessageBoxImage.Information);
}

private void ShowNumbersButton_Click(object sender, RoutedEventArgs e)
{
    string message = "Book Numbers:\n";

    ObservableCollection<string> bookNumbers = BookNumbers;
    foreach (string bookNumber in bookNumbers)
    {
        message += bookNumber + "\n";
    }

    MessageBox.Show(message, "Book Numbers", MessageBoxButton.OK, MessageBoxImage.Information);
}


        private void ShowScoreButton_Click(object sender, RoutedEventArgs e)
        {
            int score = CalculateScore();
            MessageBox.Show($"Your Score: {score}", "Quiz Score", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private int CalculateScore()
        {
            return score;
        }

        private List<MatchingQuestion> InitializeIdentifyingAreasQuestions()
        {
            List<MatchingQuestion> questions = new List<MatchingQuestion>
            {
                new MatchingQuestion
                {
                    Options = new List<string> { "000s", "100s", "200s", "300s", "400s" },
                    CorrectAnswers = new List<string> { "000s", "100s", "200s", "300s", "400s" }
                },
                // Add more questions as needed
            };

            return questions;
        }

        private class MatchingQuestion
        {
            public List<string> Options { get; set; }
            public List<string> CorrectAnswers { get; set; }

            public void GenerateRandomOptionsDescriptionsToCallNumbers()
            {
                List<string> possibleCallNumbers = new List<string>
                {
                    "000s",
                    "100s",
                    "200s",
                    "300s",
                    "400s",
                    "500s",
                    "600s",
                    "700s",
                    "800s",
                    "900s"
                };

                Options = possibleCallNumbers.OrderBy(_ => Guid.NewGuid()).Take(4).ToList();
                Options.Add(CorrectAnswers[0]);
                Options = Options.OrderBy(_ => Guid.NewGuid()).ToList();
            }

            public void GenerateRandomOptionsCallNumbersToDescriptions()
            {
                List<string> possibleDescriptions = new List<string>
                {
                    "Description 1",
                    "Description 2",
                    "Description 3",
                    "Description 4",
                    "Description 5",
                    "Description 6",
                    "Description 7"
                };

                Options = possibleDescriptions.OrderBy(_ => Guid.NewGuid()).Take(4).ToList();
                Options.Add(CorrectAnswers[0]);
                Options = Options.OrderBy(_ => Guid.NewGuid()).ToList();
            }
        }
    }
}
